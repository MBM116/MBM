Basilisk EA  (MetaTrader 5)

HOW TO USE
- Copy "Basilisk EA.ex5" into your MQL5\Experts\ folder (File -> Open Data Folder), refresh Navigator, drag onto a chart.

RECOMPILE (source included)
- Source is in Source\Basilisk EA.mq5. Open in MetaEditor and press F7.

LICENSE
- BSD-3-Clause (see Source\LICENSE.txt). Based on open-source work by elrizwiraswara - https://github.com/elrizwiraswara/nyao_scalper_mt5. Free to use.

Free download courtesy of binaryforexea.com
